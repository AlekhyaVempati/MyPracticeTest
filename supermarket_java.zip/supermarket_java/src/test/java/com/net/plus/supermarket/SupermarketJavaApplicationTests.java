package com.net.plus.supermarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupermarketJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
