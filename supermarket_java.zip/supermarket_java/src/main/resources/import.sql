insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (1, 'A', 50.0, 3, 130.0);
insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (2, 'B', 30.0, 2, 45.0);
insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (3, 'C', 20.0, 2, 38.0);
insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (4, 'C', 20.0, 3, 50.0);
insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (5, 'D', 15.0, 2, 5.0);
insert into super_market (item_number, item_name, unit_price, quantity, spl_price) values (6, 'E', 5.0, 1, 5.0);