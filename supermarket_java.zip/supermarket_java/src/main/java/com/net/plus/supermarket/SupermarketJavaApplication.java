package com.net.plus.supermarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupermarketJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupermarketJavaApplication.class, args);
	}

}
