package com.net.plus.supermarket.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Null;

import lombok.Data;

/**
 * SuperMarket Entity
 * @author Alekhya
 *
 */
@Entity
@Data
public class SuperMarket {

	@Id
	private Long itemNumber;
	@NotNull
	private String itemName;
	@NotNull
	private double unitPrice;
	@Null
	private int quantity;
	@Null
	private double splPrice;

}
