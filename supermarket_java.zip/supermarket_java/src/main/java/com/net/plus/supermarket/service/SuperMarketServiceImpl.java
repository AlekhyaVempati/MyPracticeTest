package com.net.plus.supermarket.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.net.plus.supermarket.model.ItemsToBeBilled;
import com.net.plus.supermarket.model.SuperMarket;
import com.net.plus.supermarket.repository.SuperMarketRepository;

/**
 * @author Alekhya
 *
 */
@Service
public class SuperMarketServiceImpl implements SuperMarketService {

	@Autowired
	private SuperMarketRepository repo;

	@Override
	public List<SuperMarket> getItemDetails(ItemsToBeBilled items) {
		return repo.findByItemName(items.getItemName());
	}

}
