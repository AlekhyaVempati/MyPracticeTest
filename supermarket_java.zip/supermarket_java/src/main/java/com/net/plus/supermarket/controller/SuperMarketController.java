package com.net.plus.supermarket.controller;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.net.plus.supermarket.model.ItemsToBeBilled;
import com.net.plus.supermarket.model.SuperMarket;
import com.net.plus.supermarket.service.SuperMarketService;

@RestController
public class SuperMarketController {

	@Autowired
	private SuperMarketService superMarketService;

	/**
	 * Post method finds the total bill amount
	 * @param items List of items to be billed
	 * @return total amount
	 */
	@PostMapping(value = "/findTotalBill")
	public Double findTotalBillBasedOnItems(@RequestBody List<ItemsToBeBilled> items) {
		double totalBill = 0.0;
		for (ItemsToBeBilled item : items) {
			List<SuperMarket> smDetails = superMarketService.getItemDetails(item);
			if (smDetails.size() == 1) {

				for (SuperMarket sm : smDetails) {
					if (item.getQuantity() < sm.getQuantity()) {
						totalBill += sm.getUnitPrice() * item.getQuantity();
					} else if (item.getQuantity() == sm.getQuantity()) {
						totalBill += sm.getSplPrice();
					} else {
						int quo = item.getQuantity() / sm.getQuantity();
						int rem = item.getQuantity() % sm.getQuantity();
						totalBill += (sm.getUnitPrice() * rem) + (sm.getSplPrice() * quo);
					}
				}
			} else {
				totalBill += findRelaventInstance(smDetails, item);
			}
		}

		return totalBill;
	}

	/**
	 * This method executes if more than one Super market objects are found.
	 * @param smDetails List of actual SP details
	 * @param item item to be billed
	 * @return total price
	 */
	private Double findRelaventInstance(List<SuperMarket> smDetails, ItemsToBeBilled item) {
		TreeMap<Integer, Double> itemsMap = new TreeMap<>();
		for (SuperMarket sm : smDetails) {
			itemsMap.put(1, sm.getUnitPrice());
			itemsMap.put(sm.getQuantity(), sm.getSplPrice());
		}

		Map.Entry<Integer, Double> low = itemsMap.floorEntry(item.getQuantity());
		Map.Entry<Integer, Double> high = itemsMap.ceilingEntry(item.getQuantity());
		Double res = null;
		if (low != null && high != null) {
			res = Math.abs(item.getQuantity() - low.getKey()) < Math.abs(item.getQuantity() - high.getKey())
					? low.getValue()
					: high.getValue();
		} else if (low != null || high != null) {
			res = low != null ? low.getValue() : high.getValue();
		}
		int qty = 0;
		if (low != null && low.getValue() == res) {
			qty = low.getKey();
		} else if (high != null && high.getValue() == res)
			qty = high.getKey();

		if (qty == item.getQuantity()) {
			return res;
		} else if (qty > item.getQuantity()) {
			res = itemsMap.get(1) * qty;
		} else if (qty < item.getQuantity()) {
			int remQty = item.getQuantity() - qty;
			int quo = item.getQuantity() / qty; // 1
			int rem = item.getQuantity() % qty; // 2
			if (itemsMap.containsKey(remQty) && remQty!=qty ) {
				res = (itemsMap.get(remQty)) + (itemsMap.get(qty) * quo);
			} else
				res = (itemsMap.get(1) * rem) + (itemsMap.get(qty) * quo);
		}
		System.out.println(res);
		return res;
	}

}
